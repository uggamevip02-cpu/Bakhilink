// bypasser.js
const fs = require('fs');
const path = require('path');
const axios = require('axios');
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const { HEADLESS, BYPASS_TIMEOUT, CACHE_DIR, SCRIPTS_DIR } = require('./config');
const chromium = require('@sparticuz/chromium');

puppeteer.use(StealthPlugin());

// Cấu hình từng site
const SITES = {
  link4m: {
    domains: ['link4m.com', 'link4m.net', 'link4m.org'],
    scriptFile: 'link4m.user.js',
  },
  link4sub: {
    domains: ['link4sub.com', 'blog.tapvietcode.com'],
    scriptFile: 'link4sub.user.js',
  },
  sitetop: {
    domains: ['sitetop.one', 'sitetop.net'],
    scriptFile: 'sitetop.user.js',
  },
  gtraffic: {
    domains: ['gtraffic.io'],
    scriptFile: 'gtraffic.user.js',
  },
  traffichub: {
    domains: ['system.traffichub.vn'],
    scriptFile: 'traffichub.user.js',
  },
  trafficviet: {
    domains: ['app.trafficviet.vn'],
    scriptFile: 'traffichub.user.js', // dùng chung script
  },
  layma: {
    domains: ['layma.net'],
    scriptFile: 'layma.user.js',
  },
  traffichd: {
    domains: ['traffichd.fun'],
    scriptFile: 'traffichd.user.js',
    special: 'api', // xử lý riêng bằng API
  },
};

// ------------------ Cache @require ------------------
if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR, { recursive: true });

async function fetchRequire(url) {
  const hash = Buffer.from(url).toString('base64url').slice(0, 40);
  const file = path.join(CACHE_DIR, hash + '.js');
  if (fs.existsSync(file)) return fs.readFileSync(file, 'utf8');
  try {
    const res = await axios.get(url, { timeout: 20000, responseType: 'text' });
    const text = typeof res.data === 'string' ? res.data : String(res.data);
    fs.writeFileSync(file, text);
    console.log(`[CACHE] Fetched require: ${url}`);
    return text;
  } catch (e) {
    console.warn(`[CACHE] Failed to fetch require: ${url} - ${e.message}`);
    return `/* FAILED REQUIRE: ${url} */`;
  }
}

// ------------------ Parse userscript ------------------
function parseUserscript(filePath) {
  if (!fs.existsSync(filePath)) {
    return { requires: [], body: '', runAt: 'document-idle' };
  }
  const content = fs.readFileSync(filePath, 'utf8');

  // Tách metadata
  const metaMatch = content.match(/\/\/\s*==UserScript==([\s\S]*?)\/\/\s*==\/UserScript==/);
  if (!metaMatch) {
    // Không có metadata -> coi toàn bộ là body
    return { requires: [], body: content, runAt: 'document-idle' };
  }

  const meta = metaMatch[1];
  const requires = [...meta.matchAll(/@require\s+(\S+)/g)].map((m) => m[1]);
  const runAtMatch = meta.match(/@run-at\s+(\S+)/);
  const runAt = runAtMatch ? runAtMatch[1] : 'document-idle';

  // Body = phần sau ==/UserScript==
  const body = content.slice(metaMatch.index + metaMatch[0].length).trim();

  return { requires, body, runAt };
}

// ------------------ GM shim ------------------
const GM_SHIM = `
(function() {
  if (window.__gmShimmed) return;
  window.__gmShimmed = true;
  window.__bypassResult = null;
  window.__bypassError = null;
  window.__bypassLogs = [];

  function log(...args) {
    try { console.log('[BYPASS]', ...args); } catch(e){}
    try { window.__bypassLogs.push(args.map(String).join(' ')); } catch(e){}
  }

  window.GM_setClipboard = function(text) {
    log('GM_setClipboard:', text);
    window.__bypassResult = String(text).trim();
  };
  window.GM = window.GM || {};
  window.GM.setClipboard = window.GM_setClipboard;

  window.GM_xmlhttpRequest = function(opts) {
    log('GM_xmlhttpRequest:', (opts.method||'GET'), opts.url);
    const init = { method: opts.method || 'GET', headers: opts.headers || {} };
    if (opts.data) init.body = opts.data;
    if (opts.timeout) {
      // mimic timeout với AbortController
      const ac = new AbortController();
      init.signal = ac.signal;
      setTimeout(() => ac.abort(), opts.timeout);
    }
    fetch(opts.url, init).then(async r => {
      const isBinary = opts.responseType === 'arraybuffer' || opts.responseType === 'blob';
      if (isBinary) {
        const buf = await r.arrayBuffer();
        opts.onload && opts.onload({ response: buf, status: r.status, readyState: 4, responseHeaders: '' });
      } else {
        const t = await r.text();
        opts.onload && opts.onload({ responseText: t, response: t, status: r.status, readyState: 4, responseHeaders: '' });
      }
    }).catch(e => { log('GM_xhr error:', e.message); opts.onerror && opts.onerror(e); });
    return { abort: () => log('abort called') };
  };
  window.GM.xmlHttpRequest = window.GM_xmlhttpRequest;

  const _storage = {};
  window.GM_getValue = (k, d) => (k in _storage ? _storage[k] : d);
  window.GM_setValue = (k, v) => { _storage[k] = v; };
  window.GM_deleteValue = (k) => { delete _storage[k]; };
  window.GM_addStyle = (css) => {
    const s = document.createElement('style');
    s.textContent = css;
    (document.head || document.documentElement).appendChild(s);
    return s;
  };
  window.GM = Object.assign(window.GM, {
    xmlHttpRequest: window.GM_xmlHttpRequest,
    getValue: window.GM_getValue,
    setValue: window.GM_setValue,
    addStyle: window.GM_addStyle,
  });

  window.unsafeWindow = window;

  window.GM_cookie = {
    list: () => Promise.resolve(
      document.cookie.split(';').filter(c => c).map(c => {
        const [name, ...v] = c.trim().split('=');
        return { name, value: v.join('='), domain: location.hostname, path: '/' };
      })
    ),
    set: (d) => { if (d.name) document.cookie = d.name + '=' + d.value + '; path=/'; return Promise.resolve(); },
    delete: (d) => { if (d.name) document.cookie = d.name + '=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT'; return Promise.resolve(); },
  };

  window.addEventListener('error', e => { log('Window error:', e.message); });
  log('GM shim installed on', location.href);
})();
`;

// Bọc code theo @run-at
function wrapScript(code, runAt) {
  const tryCatch = `
    try { ${code} } catch (e) { console.error('[BYPASS] Script error:', e); window.__bypassError = String(e); }
  `;
  if (runAt === 'document-start') return tryCatch;
  if (runAt === 'document-end') {
    return `(function(){
      function run(){ ${tryCatch} }
      if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', run);
      else run();
    })();`;
  }
  // document-idle
  return `(function(){
    function run(){ ${tryCatch} }
    if (document.readyState === 'complete') setTimeout(run, 400);
    else window.addEventListener('load', () => setTimeout(run, 600));
  })();`;
}

// ------------------ Detect site ------------------
function detectSite(url) {
  let host;
  try { host = new URL(url).hostname; } catch { return null; }
  for (const [key, site] of Object.entries(SITES)) {
    if (site.domains.some((d) => host === d || host.endsWith('.' + d))) return key;
  }
  return null;
}

// ------------------ Special: TrafficHD qua API ------------------
async function bypassTrafficHD(url) {
  const parts = new URL(url).pathname.split('/').filter(Boolean);
  const id = parts[0];
  if (!id) throw new Error('Link TrafficHD không hợp lệ');
  const res = await axios.get(`https://traffichd.fun/api/get-link/${id}`, { timeout: 30000 });
  const finalUrl = res.data && (res.data.originalUrl || res.data.backupUrl);
  if (!finalUrl) throw new Error('Không tìm thấy link đích');
  return finalUrl;
}

// ------------------ Bypass chính (Puppeteer) ------------------
async function bypassPuppeteer(url, siteKey) {
  const site = SITES[siteKey];
  const scriptPath = path.join(SCRIPTS_DIR, site.scriptFile);
  const { requires, body, runAt } = parseUserscript(scriptPath);

  // Tải trước @require (cache)
  const requireCodes = [];
  for (const reqUrl of requires) {
    requireCodes.push(await fetchRequire(reqUrl));
  }
  const requireBlob = requireCodes.join('\n;\n');

    const browser = await puppeteer.launch({
    args: [
      ...chromium.args, // Lấy các tham số mặc định của môi trường server
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--disable-blink-features=AutomationControlled'
    ],
    defaultViewport: chromium.defaultViewport,
    executablePath: await chromium.executablePath(),
    headless: "shell",
  });
  

  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 1366, height: 800 });

    // Bật log để debug
    page.on('console', (msg) => {
      const t = msg.text();
      if (t.includes('[BYPASS]') || t.includes('error')) console.log('[page]', t);
    });

    // Chuẩn bị script inject
    const fullBody = body ? wrapScript(body, runAt) : '';
    const requiresWrapped = requireBlob ? wrapScript(requireBlob, 'document-start') : '';
    const injectCode = [GM_SHIM, requiresWrapped, fullBody].filter(Boolean).join('\n;\n');

    // Inject vào MỌI navigation (xử lý redirect chain)
    await page.evaluateOnNewDocument(injectCode);

    // Track URL để phát hiện điều hướng đến link đích
    let lastNavUrl = null;
    const navigations = [];
    page.on('framenavigated', (frame) => {
      if (frame === page.mainFrame()) {
        const u = frame.url();
        if (u && !u.startsWith('about:') && u !== lastNavUrl) {
          lastNavUrl = u;
          navigations.push({ url: u, at: Date.now() });
          console.log('[nav]', u);
        }
      }
    });

    console.log(`[bypass] Navigating to: ${url}`);
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: BYPASS_TIMEOUT });

    // Chờ kết quả: ưu tiên GM_setClipboard, fallback URL navigation
    const startTime = Date.now();
    const startHost = new URL(url).hostname;
    let result = null;

    while (Date.now() - startTime < BYPASS_TIMEOUT) {
      // 1) Kiểm tra clipboard result
      try {
        const clip = await page.evaluate('window.__bypassResult').catch(() => null);
        if (clip && typeof clip === 'string' && clip.trim()) {
          result = clip.trim();
          console.log('[bypass] Got clipboard result:', result);
          break;
        }
      } catch {}

      // 2) Kiểm tra URL đã rời khỏi domain gốc chưa
      try {
        const curUrl = page.url();
        if (curUrl && !curUrl.startsWith('about:')) {
          const curHost = new URL(curUrl).hostname;
          const isOffsite = !SITES[siteKey].domains.some(
            (d) => curHost === d || curHost.endsWith('.' + d)
          );
          if (isOffsite) {
            // Đợi thêm 2s để đảm bảo không phải redirect trung gian
            await new Promise((r) => setTimeout(r, 2000));
            const finalUrl = page.url();
            if (finalUrl === curUrl) {
              result = finalUrl;
              console.log('[bypass] Got navigation result:', result);
              break;
            }
          }
        }
      } catch {}

      await new Promise((r) => setTimeout(r, 800));
    }

    if (!result) {
      // Fallback: lấy URL hiện tại nếu khác ban đầu
      const curUrl = page.url();
      if (curUrl && curUrl !== url && !curUrl.startsWith('about:')) {
        result = curUrl;
      }
    }

    if (!result) {
      throw new Error('Không tìm được link đích (timeout hoặc script lỗi). Thử lại sau.');
    }

    return result;
  } finally {
    await browser.close().catch(() => {});
  }
}

// ------------------ Export ------------------
async function bypass(url) {
  const siteKey = detectSite(url);
  if (!siteKey) throw new Error('❌ Link không được hỗ trợ.');

  if (SITES[siteKey].special === 'api') {
    return bypassTrafficHD(url);
  }
  return bypassPuppeteer(url, siteKey);
}

module.exports = { bypass, detectSite, SITES };