// config.js
module.exports = {
  // Tự động lấy từ biến môi trường của host (Katabump Variables)
  BOT_TOKEN: process.env.BOT_TOKEN || '8472600933:AAGONDM6ZYG5eMVh00zmUAtbHlZJzy8AJxc', 
  ADMIN_IDS: (process.env.ADMIN_IDS || '8175673206').split(',').filter(Boolean).map(Number),

  HEADLESS: process.env.HEADLESS !== 'false',
  BYPASS_TIMEOUT: 90000,
  DB_FILE: './data.json',
  CACHE_DIR: './cache',
  SCRIPTS_DIR: './scripts',
};