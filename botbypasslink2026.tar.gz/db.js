// db.js
const fs = require('fs');
const path = require('path');
const { DB_FILE } = require('./config');

const DEFAULT_DATA = {
  users: {},       // { [userId]: { id, username, coins, banned, joinedAt } }
  admins: [],      // [userId]
  codes: {},       // { code: { amount, uses, maxUses, usedBy: [] } }
  config: {
    groupId: null,
    groupLink: null,
    prices: {
      link4m: 1,
      link4sub: 1,
      sitetop: 1,
      gtraffic: 2,
      traffichub: 2,
      trafficviet: 2,
      layma: 2,
      traffichd: 1,
    },
  },
  stats: { totalBypasses: 0, totalUsers: 0 },
};

let data = JSON.parse(JSON.stringify(DEFAULT_DATA));

function load() {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
      data = {
        ...DEFAULT_DATA,
        ...raw,
        config: {
          ...DEFAULT_DATA.config,
          ...(raw.config || {}),
          prices: { ...DEFAULT_DATA.config.prices, ...((raw.config && raw.config.prices) || {}) },
        },
      };
      console.log(`[DB] Loaded ${Object.keys(data.users).length} users`);
    } else {
      save();
    }
  } catch (e) {
    console.error('[DB] Load failed:', e.message);
  }
}

let writeQueue = Promise.resolve();
function save() {
  writeQueue = writeQueue
    .then(() => fs.promises.writeFile(DB_FILE, JSON.stringify(data, null, 2)))
    .catch((e) => console.error('[DB] Save failed:', e.message));
  return writeQueue;
}

function getUser(id) {
  id = Number(id);
  if (!data.users[id]) {
    data.users[id] = {
      id,
      username: null,
      coins: 0,
      banned: false,
      joinedAt: Date.now(),
    };
    data.stats.totalUsers = Object.keys(data.users).length;
    save();
  }
  return data.users[id];
}

function isAdmin(id) {
  return data.admins.includes(Number(id));
}

function addAdmin(id) {
  if (!isAdmin(id)) {
    data.admins.push(Number(id));
    save();
  }
}

function removeAdmin(id) {
  data.admins = data.admins.filter((x) => x !== Number(id));
  save();
}

function setCoins(id, amount) {
  const u = getUser(id);
  u.coins = Math.max(0, amount);
  save();
}

function addCoins(id, amount) {
  const u = getUser(id);
  u.coins += amount;
  save();
}

function deductCoins(id, amount) {
  const u = getUser(id);
  u.coins = Math.max(0, u.coins - amount);
  save();
}

function banUser(id, banned = true) {
  const u = getUser(id);
  u.banned = banned;
  save();
}

function createCode(amount, maxUses) {
  const code = 'BC-' + Math.random().toString(36).substring(2, 10).toUpperCase();
  data.codes[code] = { amount, uses: 0, maxUses, usedBy: [] };
  save();
  return code;
}

function redeemCode(code, userId) {
  code = code.trim().toUpperCase();
  const c = data.codes[code];
  if (!c) return { ok: false, msg: '❌ Code không tồn tại.' };
  if (c.uses >= c.maxUses) return { ok: false, msg: '❌ Code đã hết lượt dùng.' };
  if (c.usedBy.includes(Number(userId))) return { ok: false, msg: '❌ Bạn đã dùng code này rồi.' };
  c.uses++;
  c.usedBy.push(Number(userId));
  addCoins(userId, c.amount);
  save();
  return { ok: true, amount: c.amount };
}

module.exports = {
  load,
  save,
  data: () => data,
  getUser,
  isAdmin,
  addAdmin,
  removeAdmin,
  setCoins,
  addCoins,
  deductCoins,
  banUser,
  createCode,
  redeemCode,
};