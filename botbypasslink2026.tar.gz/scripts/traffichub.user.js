// ==UserScript==
// @name         TrafficViet & TrafficHub Bypasser
// @version      1.0.0
// @match        *://app.trafficviet.vn/*
// @match        *://system.traffichub.vn/*
// @grant        GM_xmlhttpRequest
// @grant        GM_cookie
// @connect      *
// @run-at       document-idle
// @require      https://duckxkurumi.xyz/bypass/traffichub-funcion.js
// ==/UserScript==

// ⚠️ Dán BODY thật vào đây nếu có.