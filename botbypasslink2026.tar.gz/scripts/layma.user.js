// ==UserScript==
// @name         Layma.net Bypass
// @version      1.1.1
// @match        https://layma.net/*
// @connect      *
// @grant        GM_xmlhttpRequest
// @grant        unsafeWindow
// @run-at       document-end
// @require      https://raw.githubusercontent.com/duckpjvzexe/projectscript112247/refs/heads/main/layma_net/ObfFuncV2.js
// ==/UserScript==

// ⚠️ Dán BODY thật vào đây nếu có.