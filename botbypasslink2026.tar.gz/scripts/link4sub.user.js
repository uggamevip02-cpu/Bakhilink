// ==UserScript==
// @name         Link4Sub Main
// @namespace    https://verrni.fun/
// @version      1.0-releases
// @description  Auto bypass Link4Sub by huyzeraa
// @author       huyzeraa
// @match        https://blog.tapvietcode.com/*
// @run-at       document-start
// @grant        unsafeWindow
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// @grant        GM_addStyle
// @connect      link4sub.com
// @require      https://cdn.verrni.fun/raw/Bypass/Link4Sub/Link4SubBP.js
// ==/UserScript==

// ⚠️ Dán BODY thật vào đây nếu có.