// ==UserScript==
// @name         TrafficHD Bypass
// @version      3.6
// @match        https://traffichd.fun/*
// @run-at       document-start
// ==/UserScript==
// (bypasser.js xử lý riêng qua API: https://traffichd.fun/api/get-link/<id>)