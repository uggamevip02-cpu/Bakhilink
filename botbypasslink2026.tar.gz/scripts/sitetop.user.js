// ==UserScript==
// @name         SiteTop Bypass
// @namespace    https://verrni.fun/
// @version      2.1.0
// @match        https://sitetop.one/*
// @match        https://sitetop.net/*
// @match        https://*.sitetop.one/*
// @match        https://*.sitetop.net/*
// @run-at       document-idle
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// @connect      sitetop.one
// @connect      sitetop.net
// @require      https://cdn.verrni.fun/raw/Bypass/SiteTop/SiteTop.js
// ==/UserScript==

// ⚠️ Dán BODY thật vào đây nếu có.