// ==UserScript==
// @name         GTraffic Bypass (VNBP)
// @namespace    https://gtraffic.io/
// @version      1.0
// @match        https://gtraffic.io/*
// @grant        GM_xmlhttpRequest
// @grant        GM_setClipboard
// @grant        GM_getValue
// @grant        GM_setValue
// @require      https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js
// @require      https://raw.githubusercontent.com/longndev/VNBP/refs/heads/main/Gaytraffic/gtraffic.js
// @connect      *
// @run-at       document-end
// ==/UserScript==

// ⚠️ Dán BODY thật vào đây nếu có.