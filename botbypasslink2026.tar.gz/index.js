// Khai báo đường dẫn thư viện cho Chromium
process.env.LD_LIBRARY_PATH = '/home/container/libs:/home/container/libs:' + (process.env.LD_LIBRARY_PATH || '');
// bot.js
const { Telegraf, Markup } = require('telegraf');
const { BOT_TOKEN, ADMIN_IDS } = require('./config');
const db = require('./db');
const { bypass, detectSite, SITES } = require('./bypasser');

if (!BOT_TOKEN || BOT_TOKEN === 'DÁN_TOKEN_VÀO_ĐÂY') {
  console.error('❌ Chưa cấu hình BOT_TOKEN trong config.js');
  process.exit(1);
}

db.load();
// Seed admin gốc
for (const id of ADMIN_IDS) db.addAdmin(id);

const bot = new Telegraf(BOT_TOKEN);
const pending = new Set(); // tránh spam 1 user 1 lúc

// ============ Helper: kiểm tra group ============
async function checkGroup(ctx) {
  if (db.isAdmin(ctx.from.id)) return { ok: true };
  const cfg = db.data().config;
  if (!cfg.groupId) return { ok: true }; // chưa cấu hình -> cho qua

  try {
    const member = await ctx.telegram.getChatMember(cfg.groupId, ctx.from.id);
    if (['left', 'kicked'].includes(member.status)) {
      return {
        ok: false,
        msg: `⚠️ Bạn phải tham gia nhóm trước khi dùng bot!\n👉 ${cfg.groupLink || 'Liên hệ admin để lấy link nhóm'}`,
      };
    }
    return { ok: true };
  } catch (e) {
    console.error('checkGroup error:', e.message);
    // Bot chưa được add vào group -> bỏ qua check
    return { ok: true };
  }
}

// ============ START / HELP ============
bot.start(async (ctx) => {
  const user = db.getUser(ctx.from.id);
  user.username = ctx.from.username || null;
  db.save();

  const cfg = db.data().config;
  let priceList = '';
  for (const [site, price] of Object.entries(cfg.prices)) {
    priceList += `  • ${site}: ${price} coin\n`;
  }

  const isAdmin = db.isAdmin(ctx.from.id);
  const coinText = isAdmin ? '∞ (admin)' : user.coins;

  const text =
    `👋 Chào *${ctx.from.first_name}*!\n\n` +
    `💰 Số dư: *${coinText}* coin\n` +
    `📊 Tổng lượt bypass: ${db.data().stats.totalBypasses}\n\n` +
    `📋 *Bảng giá:*\n${priceList}\n` +
    `📌 *Cách dùng:* Gửi link cần vượt, bot xử lý tự động.\n` +
    `🎟️ Redeem code: /redeem <code>\n` +
    `💳 Nạp coin: liên hệ admin\n` +
    (isAdmin ? `\n🔑 Admin: gõ /admin để mở bảng điều khiển` : '');

  await ctx.replyWithMarkdown(text);
});

bot.help(async (ctx) => {
  await ctx.reply(
    `📖 *Hướng dẫn:*\n` +
      `• Gửi link (http/https) -> bot tự vượt (trừ coin theo bảng giá)\n` +
      `• /start — xem số dư + bảng giá\n` +
      `• /balance — kiểm tra coin\n` +
      `• /redeem <code> — nhập code cộng coin\n` +
      `• /help — trợ giúp\n\n` +
      `🔑 *Admin:* /admin`,
    { parse_mode: 'Markdown' }
  );
});

bot.command('balance', async (ctx) => {
  const u = db.getUser(ctx.from.id);
  const coin = db.isAdmin(ctx.from.id) ? '∞ (admin)' : u.coins;
  await ctx.reply(`💰 Số dư: *${coin}* coin`, { parse_mode: 'Markdown' });
});

// ============ REDEEM ============
bot.command('redeem', async (ctx) => {
  const args = ctx.message.text.split(' ').slice(1);
  if (!args[0]) return ctx.reply('⚠️ Cú pháp: /redeem <code>');
  const res = db.redeemCode(args[0], ctx.from.id);
  if (!res.ok) return ctx.reply(res.msg);
  await ctx.reply(`✅ Nhận thành công *${res.amount} coin*!\n💰 Số dư mới: *${db.getUser(ctx.from.id).coins}*`, {
    parse_mode: 'Markdown',
  });
});

// ============ BYPASS (main) ============
bot.on('text', async (ctx) => {
  const text = ctx.message.text.trim();
  if (!/^https?:\/\//i.test(text)) return; // không phải link, bỏ qua
  if (pending.has(ctx.from.id)) {
    return ctx.reply('⏳ Bạn đang có 1 yêu cầu chạy. Vui lòng chờ!');
  }

  const user = db.getUser(ctx.from.id);
  user.username = ctx.from.username || null;
  if (user.banned) return ctx.reply('🚫 Bạn đã bị ban khỏi bot.');

  const groupCheck = await checkGroup(ctx);
  if (!groupCheck.ok) return ctx.reply(groupCheck.msg);

  const siteKey = detectSite(text);
  if (!siteKey) {
    return ctx.reply('❌ Link này chưa được hỗ trợ.\nCác trang hỗ trợ: ' + Object.keys(SITES).join(', '));
  }

  const isAdmin = db.isAdmin(ctx.from.id);
  const price = db.data().config.prices[siteKey] ?? 1;

  if (!isAdmin && user.coins < price) {
    return ctx.reply(
      `💸 Bạn cần *${price} coin* để vượt link này.\n💰 Số dư hiện tại: *${user.coins} coin*\n👉 Nạp coin: liên hệ admin.`,
      { parse_mode: 'Markdown' }
    );
  }

  pending.add(ctx.from.id);
  const statusMsg = await ctx.reply(`⏳ Đang vượt *${siteKey}*... (${price} coin)`, {
    parse_mode: 'Markdown',
  });

  try {
    const result = await bypass(text);

    // Trừ coin (admin free)
    if (!isAdmin) db.deductCoins(ctx.from.id, price);
    db.data().stats.totalBypasses++;
    db.save();

    const newBal = isAdmin ? '∞' : db.getUser(ctx.from.id).coins;
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      statusMsg.message_id,
      null,
      `✅ *Thành công!* (-${isAdmin ? 0 : price} coin)\n💰 Số dư: *${newBal}*\n\n🔗 \`${result}\``,
      { parse_mode: 'Markdown', disable_web_page_preview: true }
    );

    // Gửi riêng link dạng text để user dễ copy
    await ctx.reply(result, { disable_web_page_preview: true });
  } catch (e) {
    console.error('[bypass error]', e);
    await ctx.telegram.editMessageText(
      ctx.chat.id,
      statusMsg.message_id,
      null,
      `❌ Lỗi: ${e.message}\n_Không trừ coin._`,
      { parse_mode: 'Markdown' }
    );
  } finally {
    pending.delete(ctx.from.id);
  }
});

// =========================================================
//                     ADMIN PANEL
// =========================================================
bot.command('admin', async (ctx) => {
  if (!db.isAdmin(ctx.from.id)) return;
  const cfg = db.data().config;
  const pricesText = Object.entries(cfg.prices)
    .map(([s, p]) => `  • ${s}: ${p} coin`)
    .join('\n');

  await ctx.replyWithMarkdown(
    `🔑 *ADMIN PANEL*\n\n` +
      `👥 Users: ${Object.keys(db.data().users).length}\n` +
      `📊 Bypass: ${db.data().stats.totalBypasses}\n` +
      `👑 Admins: ${db.data().admins.join(', ')}\n` +
      `🏠 Group ID: ${cfg.groupId || '_chưa set_'}\n` +
      `🔗 Group link: ${cfg.groupLink || '_chưa set_'}\n\n` +
      `💵 *Giá:*\n${pricesText}\n\n` +
      `*Lệnh quản lý:*\n` +
      `• /addcoin <id> <sl> — cộng coin\n` +
      `• /subcoin <id> <sl> — trừ coin\n` +
      `• /setcoin <id> <sl> — đặt số dư\n` +
      `• /checkuser <id> — xem info user\n` +
      `• /ban <id> | /unban <id>\n` +
      `• /setprice <site> <coin>\n` +
      `• /setgroup <group_id>\n` +
      `• /setgrouplink <link>\n` +
      `• /createcode <sl_coin> <số_lần_dùng>\n` +
      `• /delcode <code>\n` +
      `• /listcodes\n` +
      `• /addadmin <id> | /deladmin <id>`
  );
});

function adminOnly(fn) {
  return async (ctx) => {
    if (!db.isAdmin(ctx.from.id)) return ctx.reply('🚫 Bạn không phải admin.');
    try { await fn(ctx); } catch (e) { await ctx.reply('❌ Lỗi: ' + e.message); }
  };
}

bot.command('addcoin', adminOnly(async (ctx) => {
  const [, id, amt] = ctx.message.text.split(/\s+/);
  if (!id || !amt) return ctx.reply('Cú pháp: /addcoin <userId> <amount>');
  db.addCoins(Number(id), Number(amt));
  await ctx.reply(`✅ Đã cộng ${amt} coin cho ${id}.\nSố dư mới: ${db.getUser(id).coins}`);
}));

bot.command('subcoin', adminOnly(async (ctx) => {
  const [, id, amt] = ctx.message.text.split(/\s+/);
  if (!id || !amt) return ctx.reply('Cú pháp: /subcoin <userId> <amount>');
  db.deductCoins(Number(id), Number(amt));
  await ctx.reply(`✅ Đã trừ ${amt} coin của ${id}.\nSố dư mới: ${db.getUser(id).coins}`);
}));

bot.command('setcoin', adminOnly(async (ctx) => {
  const [, id, amt] = ctx.message.text.split(/\s+/);
  if (!id || !amt) return ctx.reply('Cú pháp: /setcoin <userId> <amount>');
  db.setCoins(Number(id), Number(amt));
  await ctx.reply(`✅ Đã đặt số dư ${id} = ${amt} coin.`);
}));

bot.command('checkuser', adminOnly(async (ctx) => {
  const id = ctx.message.text.split(/\s+/)[1];
  if (!id) return ctx.reply('Cú pháp: /checkuser <userId>');
  const u = db.getUser(id);
  await ctx.replyWithMarkdown(
    `👤 *User info*\n` +
      `ID: \`${u.id}\`\n` +
      `Username: ${u.username ? '@' + u.username : '_không có_'}\n` +
      `💰 Coins: ${u.coins}\n` +
      `🚫 Banned: ${u.banned ? 'Có' : 'Không'}\n` +
      `📅 Tham gia: ${new Date(u.joinedAt).toLocaleString('vi-VN')}`
  );
}));

bot.command('ban', adminOnly(async (ctx) => {
  const id = ctx.message.text.split(/\s+/)[1];
  if (!id) return ctx.reply('Cú pháp: /ban <userId>');
  db.banUser(Number(id), true);
  await ctx.reply(`🔨 Đã ban ${id}.`);
}));

bot.command('unban', adminOnly(async (ctx) => {
  const id = ctx.message.text.split(/\s+/)[1];
  if (!id) return ctx.reply('Cú pháp: /unban <userId>');
  db.banUser(Number(id), false);
  await ctx.reply(`✅ Đã unban ${id}.`);
}));

bot.command('setprice', adminOnly(async (ctx) => {
  const [, site, price] = ctx.message.text.split(/\s+/);
  if (!site || price === undefined) return ctx.reply('Cú pháp: /setprice <site> <coin>');
  if (!(site in db.data().config.prices)) {
    return ctx.reply(`❌ Site không tồn tại. Các site: ${Object.keys(db.data().config.prices).join(', ')}`);
  }
  db.data().config.prices[site] = Number(price);
  db.save();
  await ctx.reply(`✅ Giá ${site} = ${price} coin.`);
}));

bot.command('setgroup', adminOnly(async (ctx) => {
  const gid = ctx.message.text.split(/\s+/)[1];
  if (!gid) return ctx.reply('Cú pháp: /setgroup <-100xxxxxxx>');
  db.data().config.groupId = gid;
  db.save();
  await ctx.reply(`✅ Group ID = ${gid}`);
}));

bot.command('setgrouplink', adminOnly(async (ctx) => {
  const link = ctx.message.text.split(/\s+/)[1];
  if (!link) return ctx.reply('Cú pháp: /setgrouplink <https://t.me/...>');
  db.data().config.groupLink = link;
  db.save();
  await ctx.reply(`✅ Group link = ${link}`);
}));

bot.command('createcode', adminOnly(async (ctx) => {
  const [, amt, uses] = ctx.message.text.split(/\s+/);
  if (!amt || !uses) return ctx.reply('Cú pháp: /createcode <số_coin> <số_lần_dùng>');
  const code = db.createCode(Number(amt), Number(uses));
  await ctx.replyWithMarkdown(
    `🎟️ *Code mới:*\n\`${code}\`\n💰 Coin: ${amt}\n🔁 Số lần dùng: ${uses}`
  );
}));

bot.command('delcode', adminOnly(async (ctx) => {
  const code = (ctx.message.text.split(/\s+/)[1] || '').toUpperCase();
  if (!code) return ctx.reply('Cú pháp: /delcode <code>');
  if (!db.data().codes[code]) return ctx.reply('❌ Code không tồn tại.');
  delete db.data().codes[code];
  db.save();
  await ctx.reply(`✅ Đã xoá code ${code}.`);
}));

bot.command('listcodes', adminOnly(async (ctx) => {
  const entries = Object.entries(db.data().codes);
  if (!entries.length) return ctx.reply('Chưa có code nào.');
  const text = entries
    .map(([c, v]) => `• \`${c}\` — ${v.amount} coin, dùng ${v.uses}/${v.maxUses}`)
    .join('\n');
  await ctx.replyWithMarkdown(`🎟️ *Danh sách code:*\n\n${text}`);
}));

bot.command('addadmin', adminOnly(async (ctx) => {
  const id = ctx.message.text.split(/\s+/)[1];
  if (!id) return ctx.reply('Cú pháp: /addadmin <userId>');
  db.addAdmin(Number(id));
  await ctx.reply(`👑 Đã thêm admin ${id}.`);
}));

bot.command('deladmin', adminOnly(async (ctx) => {
  const id = ctx.message.text.split(/\s+/)[1];
  if (!id) return ctx.reply('Cú pháp: /deladmin <userId>');
  db.removeAdmin(Number(id));
  await ctx.reply(`✅ Đã xoá admin ${id}.`);
}));

// ============ Khởi động ============
bot.launch().then(() => {
  console.log('🤖 Bot đã khởi động!');
  console.log(`👑 Admins: ${db.data().admins.join(', ')}`);
});
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));